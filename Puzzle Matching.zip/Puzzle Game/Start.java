public class Start {

    public static void main(String []arg){
        PuzzelGame puzzleGame = new PuzzelGame();
                  puzzleGame.setVisible(true);
        }
}
